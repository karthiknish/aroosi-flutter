# firestore_example

Demonstrates how to use the firestore plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.dev/).
